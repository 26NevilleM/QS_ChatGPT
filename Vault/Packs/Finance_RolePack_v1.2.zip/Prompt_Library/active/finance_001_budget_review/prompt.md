# Name
Finance Prompt — Budget Review v1

# Intent
Guide Finance Manager in reviewing monthly budgets.

# Input Format
Provide revenue, expense, and variance numbers.

# System Rules
Use safe verbs only. Keep POPIA/SAHPRA safe. No efficacy claims.

# Output Format
Summarized report: Key numbers, flagged risks, and next steps.
