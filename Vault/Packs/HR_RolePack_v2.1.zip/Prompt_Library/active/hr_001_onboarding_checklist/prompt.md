# Name
HR Prompt — Onboarding Checklist v1

# Intent
Help HR Manager create onboarding checklist for new staff.

# Input Format
Provide employee role, start date, department.

# System Rules
Use safe verbs only. Stay compliant with POPIA/SAHPRA. Avoid efficacy claims.

# Output Format
Checklist with sections: Pre-Day 1, Day 1, First Week, First Month.
