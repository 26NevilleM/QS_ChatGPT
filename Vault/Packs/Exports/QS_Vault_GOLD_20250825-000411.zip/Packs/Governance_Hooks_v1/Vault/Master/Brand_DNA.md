# Brand DNA — Q‑Surgical
Palette: #000000 (black) • #B5D443 (green) • #FFFFFF (white)
Fonts: Good Times (headings), Bahnschrift (body)
Aesthetic: sleek, futuristic, high‑contrast, holographic, wireframe, sci‑fi
Tone: smart, bold, professional, human
Compliance: POPIA + SAHPRA aligned. Use safe verbs: supports, enables, helps.
