import json, re, os, sys, hashlib
BASE = os.path.expanduser("~/Library/CloudStorage/GoogleDrive-design@qsurgical.co.za/My Drive/QS_ChatGPT/Vault")
root = os.path.join(BASE, "Prompt_Library")
catalog_path = os.path.join(root, "_catalog", "prompts_catalog.json")
with open(catalog_path, "r", encoding="utf-8") as f:
    catalog = json.load(f)
ids = []
ids += catalog.get("active", [])
ids += catalog.get("sandbox", [])
ids += catalog.get("deprecated", [])
required_headers = [r"^# Name\b", r"^# Intent\b", r"^# Output Format\b"]
prohibited = re.compile(r"\b(cures|proves|guarantees)\b", re.IGNORECASE)
def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        h.update(f.read())
    return h.hexdigest()
def validate_id(pid):
    found = None
    for state in ["active","sandbox","deprecated"]:
        d = os.path.join(root, state, pid)
        if os.path.isdir(d):
            found = (state, d)
            break
    if not found:
        return [f"missing_dir:{pid}"]
    state, d = found
    issues = []
    mp = os.path.join(d, "meta.json")
    pp = os.path.join(d, "prompt.md")
    if not os.path.isfile(mp):
        issues.append(f"missing_meta:{pid}")
    if not os.path.isfile(pp):
        issues.append(f"missing_prompt:{pid}")
    if issues:
        return issues
    try:
        meta = json.load(open(mp, "r", encoding="utf-8"))
    except Exception:
        issues.append(f"meta_json_invalid:{pid}")
        return issues
    for k in ["id","title","version","status"]:
        if not meta.get(k):
            issues.append(f"meta_missing_{k}:{pid}")
    v = meta.get("version","")
    if not re.match(r"^\d+\.\d+\.\d+$", v):
        issues.append(f"meta_version_semver:{pid}")
    text = open(pp, "r", encoding="utf-8").read()
    for hdr in required_headers:
        if not re.search(hdr, text, flags=re.MULTILINE):
            issues.append(f"prompt_missing_header:{pid}")
    if prohibited.search(text):
        issues.append(f"prompt_prohibited_verbs:{pid}")
    chk = sha256(pp)
    if meta.get("checksum_sha256","") and meta["checksum_sha256"] != chk:
        issues.append(f"checksum_mismatch:{pid}")
    return issues
all_issues = []
for pid in ids:
    all_issues += validate_id(pid)
if all_issues:
    print("\n".join(all_issues))
    sys.exit(1)
print("OK")
