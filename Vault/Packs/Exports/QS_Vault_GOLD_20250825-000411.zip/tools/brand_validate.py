#!/usr/bin/env python3
import os, sys, re, json

def here():
    return os.path.dirname(os.path.abspath(__file__))

def vault_base():
    return os.path.dirname(here())

BASE = vault_base()
PL = os.path.join(BASE, "Prompt_Library")
ACTIVE = os.path.join(PL, "active")
MASTER = os.path.join(BASE, "Master")
BRAND = os.path.join(MASTER, "Brand_DNA.md")

PALETTE = {"#000000", "#B5D443", "#FFFFFF"}
FONTS = {"Good Times", "Bahnschrift"}
BANNED = re.compile(r'\b(cure|cures|guarantee|guarantees|100%|zero complications)\b', re.IGNORECASE)
REQ_HEADERS = [r'^#\s*Name\b', r'^#\s*Intent\b', r'^#\s*Input\s*Format\b', r'^#\s*System\s*Rules\b', r'^#\s*Output\s*Format\b']

issues = []

def read(p):
    try:
        with open(p, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return ""

if not os.path.isfile(BRAND):
    issues.append("brand_missing:Master/Brand_DNA.md")
else:
    txt = read(BRAND)
    for hexv in PALETTE:
        if hexv not in txt:
            issues.append(f"brand_palette_missing:{hexv}")
    for font in FONTS:
        if font not in txt:
            issues.append(f"brand_font_missing:{font}")

if os.path.isdir(ACTIVE):
    for pid in sorted(os.listdir(ACTIVE)):
        d = os.path.join(ACTIVE, pid)
        if not os.path.isdir(d):
            continue
        pm = os.path.join(d, "prompt.md")
        if not os.path.isfile(pm):
            issues.append(f"prompt_missing_file:{pid}")
            continue
        text = read(pm)
        for pat in REQ_HEADERS:
            if not re.search(pat, text, flags=re.MULTILINE):
                issues.append(f"prompt_missing_header:{pid}:{pat}")
        if not re.search(r'safe verbs', text, flags=re.IGNORECASE):
            issues.append(f"prompt_missing_safe_verbs_note:{pid}")
        if BANNED.search(text):
            issues.append(f"prompt_banned_claim:{pid}")

if issues:
    print("\n".join(issues))
    sys.exit(1)
print("BRAND_OK")
