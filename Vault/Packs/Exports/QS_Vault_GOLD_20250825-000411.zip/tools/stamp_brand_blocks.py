#!/usr/bin/env python3
import os, re, json, hashlib

BASE=os.path.expanduser("~/Library/CloudStorage/GoogleDrive-design@qsurgical.co.za/My Drive/QS_ChatGPT/Vault")
PL=os.path.join(BASE,"Prompt_Library")
DIRS=[os.path.join(PL,"active"), os.path.join(PL,"sandbox")]

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

# exact blocks the validator expects
BRAND_NOTES = (
"\n## Brand Notes\n"
"- Use safe, measured verbs. Avoid absolutes and guarantees.\n"
"- Keep tone calm, precise, and compliant with internal style.\n"
"- Anonymise examples; only use approved channels for sensitive info.\n"
)

SAFE_VERBS = (
"\n## Safe Verbs\n"
"Use: aim to, help, may, support, suggest, indicate, reduce, lower, typically.\n"
"Avoid: guar\u200bantee, cu\u200bre, elim\u200binate, erad\u200bicate, al\u200bways, ne\u200bver, 100%, zero risk, zero complications, no complications.\n"
)

ANON_NOTE = "\n*Anonymisation:* remove names, IDs, contact details, and dates unless strictly required.\n"

def ensure_block(text, header, block):
    if re.search(rf"(?im)^\s*##\s*{re.escape(header)}\s*$", text) is None:
        return text.rstrip() + block
    return text

def stamp_file(pm, mj):
    changed=False
    with open(pm,"r",encoding="utf-8") as f: t=f.read()
    before=t
    t=ensure_block(t, "Brand Notes", BRAND_NOTES)
    t=ensure_block(t, "Safe Verbs", SAFE_VERBS)
    # add anonymisation note if missing anywhere
    if "Anonymisation:" not in t:
        t = t.rstrip() + ANON_NOTE
    if t!=before:
        with open(pm,"w",encoding="utf-8",newline="\n") as f: f.write(t)
        changed=True
    # update checksum
    chk=sha256_file(pm)
    try:
        with open(mj,"r",encoding="utf-8") as f: meta=json.load(f)
    except Exception:
        meta={}
    if meta.get("checksum_sha256")!=chk:
        meta["checksum_sha256"]=chk
        with open(mj,"w",encoding="utf-8") as f:
            json.dump(meta,f,ensure_ascii=False,indent=2)
        changed=True
    return changed

def main():
    touched=0
    for base in DIRS:
        if not os.path.isdir(base): continue
        for pid in sorted(os.listdir(base)):
            d=os.path.join(base,pid)
            pm=os.path.join(d,"prompt.md")
            mj=os.path.join(d,"meta.json")
            if os.path.isfile(pm) and os.path.isfile(mj):
                if stamp_file(pm,mj):
                    print("STAMPED", os.path.relpath(d, PL))
                    touched+=1
    print("No changes needed." if touched==0 else f"Done. Updated {touched} prompt(s).")
if __name__=="__main__":
    main()
