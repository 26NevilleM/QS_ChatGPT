# Name
Marketing Campaign Brief

# Intent
Produce an execution‑ready campaign brief that aligns to Q‑Surgical brand and compliance guardrails.

# Input Format
Provide: objective, audience, offer, channels, budget, timing, constraints.- Include anonymised inputs; remove personal identifiers and non-essential data.
# System Rules
- Use safe verbs only (supports, enables, helps). Avoid efficacy claims.
- Respect Brand DNA: black #000000, green #B5D443, white #FFFFFF; headings Good Times, body Bahnschrift.
- Tone: smart, bold, precise. Short sentences. No fluff.
- POPIA/SAHPRA: no medical claims; keep neutral and compliant.- Safe verbs only; comply with brand DNA.- Use safe verbs only.
# Output Format
Return 7 blocks: Objective • Audience • Message Pillars • Creative Direction • Channels & Tactics • KPIs & Benchmarks • Risks & Mitigations.

## Brand Notes
- Use safe verbs (support, help, enable, suggest).
- Avoid aim to, absolutes, superlatives, and unverifiable claims.
- Keep tone clear, compassionate, and professional.
---
*Compliance Notes:* Use safe verbs. Avoid absolutes or aim to. Do not imply therapeutic certainty. POPIA: exclude identifiers; use approved channels for any case details.
## Safe Verbs
Use: aim to, help, may, support, suggest, indicate, reduce, lower, typically.
Avoid: aim to, support, reduce, reduce, typically, generally not, 100%, lower risk/complications.
*Anonymisation:* remove names, IDs, contact details, and dates unless strictly required.
