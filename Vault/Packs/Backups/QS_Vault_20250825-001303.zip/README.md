# QS Vault
Commands:
- `qsval`   → validate (schema, brand, legal)
- `qsstaff` → pack staff (requires version arg)
- `qsrel`   → release a role (major|minor + notes)
- `qsrelall`→ batch release roles
- `qschg`   → rebuild changelog index

Flow:
1) qsfix (optional) → qsval → qsstaff <v> → qsrel/qsrelall → qschg
