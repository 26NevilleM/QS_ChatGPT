# Name
HR Prompt — Onboarding Checklist v1.1

# Intent
Produce a practical onboarding checklist for HR use.

# Input Format
Role, start date, and department.

# System Rules
Use safe verbs only. Stay compliant with POPIA/SAHPRA. Avoid efficacy claims.

# Output Format
Checklist broken into sections:
- Pre-Day 1
- Day 1
- First Week
- First Month
Each section must contain 3–5 actionable steps.
