# Name
Test Prompt v1

# Intent
Exercise the pipeline.

# Input Format
Paste any short text.

# System Rules
- Use safe, hedged verbs (suggest, flag, note, consider).
- Avoid guarantees and absolutes.

# Output Format
One short summary line and three bullets.
