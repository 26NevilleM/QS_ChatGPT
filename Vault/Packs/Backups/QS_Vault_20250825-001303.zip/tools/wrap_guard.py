#!/usr/bin/env python3
import os, sys, subprocess, shlex

# ANSI colors
G = "\033[32m"   # green
R = "\033[31m"   # red
Y = "\033[33m"   # yellow
B = "\033[34m"   # blue
DIM = "\033[2m"
RESET = "\033[0m"

def main():
    if len(sys.argv) < 2:
        print(f"{R}usage:{RESET} wrap_guard.py <script_to_run> [args...]")
        sys.exit(2)

    target = sys.argv[1]
    args = sys.argv[2:]

    base = os.path.expanduser('~/Library/CloudStorage/GoogleDrive-design@qsurgical.co.za/My Drive/QS_ChatGPT/Vault')
    validate_all = os.path.join(base, 'tools', 'validate_all.py')

    if not os.path.isfile(validate_all):
        print(f"{R}ERROR:{RESET} missing validator -> {validate_all}")
        sys.exit(2)

    print(f"{B}▶ Validating (schema + legal)…{RESET}")
    v = subprocess.run(["python3", validate_all], capture_output=True, text=True)
    # Pass through validator stdout/stderr
    if v.stdout.strip():
        for line in v.stdout.splitlines():
            tag = line.strip().upper()
            if tag in ("OK", "LEGAL_OK", "ALL_VALIDATIONS_OK"):
                color = G
            elif "FAIL" in tag:
                color = R
            else:
                color = Y
            print(color + line + RESET)
    if v.stderr.strip():
        print(v.stderr, file=sys.stderr, end="")
    if v.returncode != 0:
        print(f"{R}✖ Validation failed. Aborting.{RESET}")
        sys.exit(v.returncode)

    # Validation passed
    print(f"{G}✓ Validation PASS. Proceeding…{RESET}")

    if not os.path.isfile(target):
        print(f"{R}ERROR:{RESET} target script not found -> {target}")
        sys.exit(2)

    cmd = ["python3", target] + args
    print(f"{B}▶ Running:{RESET} {DIM}{shlex.join(cmd)}{RESET}")
    p = subprocess.run(cmd, capture_output=True, text=True)

    # Stream outputs with mild tint
    if p.stdout.strip():
        print(p.stdout, end="")
    if p.stderr.strip():
        print(p.stderr, file=sys.stderr, end="")

    if p.returncode == 0:
        print(f"{G}✓ Done.{RESET}")
    else:
        print(f"{R}✖ Script error (exit {p.returncode}).{RESET}")
    sys.exit(p.returncode)

if __name__ == "__main__":
    main()
