#!/usr/bin/env python3
import os, re, sys, json, hashlib, shutil

BASE=os.path.expanduser("~/Library/CloudStorage/GoogleDrive-design@qsurgical.co.za/My Drive/QS_ChatGPT/Vault")
PL=os.path.join(BASE,"Prompt_Library")
DIRS=[os.path.join(PL,"active"), os.path.join(PL,"sandbox")]

# Terms we never want in operative text (but allow inside obfuscated "Avoid" list)
PROHIBITED_TERMS = [
  r"\bguarantee(?:s|d)?\b", r"\bcure(?:s|d)?\b", r"\beliminate(?:s|d)?\b",
  r"\beradicate(?:s|d)?\b", r"\bzero complications\b", r"\bno complications\b",
  r"\bno risk\b", r"\bzero risk\b", r"\b100%\b", r"\balways\b", r"\bnever\b",
]

# Safer replacements for operative text
REPLACEMENTS = [
  (r"\bguarantee(?:s|d)?\b", "aim to"),
  (r"\bcure(?:s|d)?\b", "support"),
  (r"\beliminate(?:s|d)?\b", "reduce"),
  (r"\beradicate(?:s|d)?\b", "reduce"),
  (r"\bzero complications\b", "lower complication risk"),
  (r"\bno complications\b", "reduced complication risk"),
  (r"\bno risk\b", "lower risk"),
  (r"\bzero risk\b", "lower risk"),
  (r"\b100%\b", "high"),
  (r"\balways\b", "typically"),
  (r"\bnever\b", "generally not"),
]

# Obfuscate prohibited tokens in "Avoid" list using zero‑width space (U+200B)
def zws(s): return s[0] + "\u200b" + s[1:] if len(s) > 1 else s

AVOID_LIST = [
  "guarantee", "cure", "eliminate", "eradicate", "always", "never", "100%", "zero risk", "zero complications", "no complications"
]
AVOID_DISPLAY = ", ".join([zws(x) for x in AVOID_LIST])

BRAND_NOTES = (
"\n## Brand Notes\n"
"- Use safe, measured verbs. Avoid absolutes and guarantees.\n"
"- Keep tone calm, precise, and compliant with internal style.\n"
"- For internal examples, anonymise data and use approved channels.\n"
)

SAFE_VERBS = (
"\n## Safe Verbs\n"
"Use: aim to, help, may, support, suggest, indicate, reduce, lower, typically.\n"
f"Avoid: {AVOID_DISPLAY}.\n"  # obfuscated
)

COMPLIANCE = (
"\n---\n"
"*Compliance Notes:* Do not imply therapeutic certainty. POPIA: exclude identifiers; use approved reporting channels. SAHPRA: avoid hard claims.\n"
)

def sha256_file(path:str)->str:
  h=hashlib.sha256()
  with open(path,"rb") as f:
    for chunk in iter(lambda: f.read(8192), b""):
      h.update(chunk)
  return h.hexdigest()

def ensure_sections(text:str)->str:
  t=text
  if re.search(r"(?im)^\s*##\s*Brand\s+Notes\s*$", t) is None:
    t = t.rstrip() + BRAND_NOTES
  if re.search(r"(?im)^\s*##\s*Safe\s+Verbs\s*$", t) is None:
    t = t.rstrip() + SAFE_VERBS
  if "Compliance Notes:" not in t:
    t = t.rstrip() + COMPLIANCE
  return t

def sanitize_text(text:str)->str:
  t=text
  for pat, repl in REPLACEMENTS:
    t=re.sub(pat, repl, t, flags=re.IGNORECASE)
  t = ensure_sections(t)
  return t

# Remove instructional blocks from scanning (so "Avoid: a\u200blways" etc. won’t trip)
SECTION_RX = re.compile(
  r"(?ims)^\s*##\s*Brand\s+Notes\s*$.*?\Z|^\s*##\s*Safe\s+Verbs\s*$.*?\Z"
)

def strip_instructional_sections(t:str)->str:
  # Replace instructional sections with empty string for scanning only
  pieces = []
  idx = 0
  for m in re.finditer(r"(?im)^\s*##\s*(Brand\s+Notes|Safe\s+Verbs)\s*$", t):
    start = m.start()
    # find next header or end
    next_header = re.search(r"(?im)^\s*##\s+\S.*$", t[m.end():])
    end = len(t) if not next_header else m.end() + next_header.start()
    pieces.append(t[idx:start])
    idx = end
  pieces.append(t[idx:])
  return "".join(pieces)

def find_offenders(text:str):
  scan_text = strip_instructional_sections(text)
  hits=[]
  for pat in PROHIBITED_TERMS:
    if re.search(pat, scan_text, flags=re.IGNORECASE):
      hits.append(pat)
  return hits

def heal_dir(d)->bool:
  pm=os.path.join(d,"prompt.md")
  mj=os.path.join(d,"meta.json")
  changed=False

  if os.path.isfile(pm):
    with open(pm,"r",encoding="utf-8") as f: t=f.read()
    s=sanitize_text(t)
    if s!=t:
      shutil.copy2(pm, pm+".bak")
      with open(pm,"w",encoding="utf-8",newline="\n") as f: f.write(s)
      changed=True

  if os.path.isfile(pm) and os.path.isfile(mj):
    chk=sha256_file(pm)
    try:
      with open(mj,"r",encoding="utf-8") as f: meta=json.load(f)
    except Exception:
      meta={}
    if meta.get("checksum_sha256") != chk:
      meta["checksum_sha256"]=chk
      with open(mj,"w",encoding="utf-8") as f:
        json.dump(meta,f,ensure_ascii=False,indent=2)
      changed=True
  return changed

def main():
  touched=0
  remaining=[]
  for base in DIRS:
    if not os.path.isdir(base): continue
    for pid in sorted(os.listdir(base)):
      d=os.path.join(base,pid)
      if not os.path.isdir(d): continue
      if heal_dir(d):
        print("HEALED", os.path.relpath(d, PL))
        touched+=1
      pm=os.path.join(d,"prompt.md")
      if os.path.isfile(pm):
        with open(pm,"r",encoding="utf-8") as f: tt=f.read()
        offenders=find_offenders(tt)
        if offenders:
          remaining.append((os.path.relpath(d, PL), sorted(set(offenders))))
  print("Done." if touched==0 else f"Done. Updated {touched} prompt(s).")
  if remaining:
    print("\nRemaining flagged terms:")
    for rel, pats in remaining:
      print(f"- {rel}: " + ", ".join(pats))
  else:
    print("No prohibited terms detected.")
if __name__=="__main__":
  sys.exit(main() or 0)
