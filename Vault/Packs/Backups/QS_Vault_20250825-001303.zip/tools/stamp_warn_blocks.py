#!/usr/bin/env python3
import os, re, sys, json, hashlib, argparse, shutil

QS = os.path.expanduser("~/Library/CloudStorage/GoogleDrive-design@qsurgical.co.za/My Drive/QS_ChatGPT/Vault")
PL = os.path.join(QS, "Prompt_Library")
CANDIDATE_DIRS = [os.path.join(PL, "active"), os.path.join(PL, "sandbox")]

SAFE_VERB_LINE = "- Use safe verbs only."
BRAND_BLOCK = """# Brand Notes
Tone: calm, precise, and helpful. Avoid hype. Prefer verbs like *support, guide, suggest, review, check*. Keep claims qualified; cite sources when relevant.
"""
ANON_LINE = "Include anonymised inputs; remove personal identifiers and non-essential data."

HDR_RE = re.compile(r"^(#+)\s+(?P<name>.+?)\s*$", re.MULTILINE)
SECTION_NAMES = {"system": "System Rules", "input": "Input Format", "brand": "Brand Notes", "data": "Data Handling"}

def sha256(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()

def split_sections(text):
    matches = list(HDR_RE.finditer(text))
    if not matches:
        return []
    sections = []
    for i,m in enumerate(matches):
        level = len(m.group(1))
        name = m.group("name").strip()
        start = m.start()
        end = matches[i+1].start() if i+1 < len(matches) else len(text)
        sections.append((level,name,start,end))
    return sections

def find_section(text, wanted):
    sections = split_sections(text)
    for lvl,name,s,e in sections:
        if name.lower().strip() == wanted.lower():
            return (lvl,name,s,e)
    return None

def ensure_system_rules(text):
    sec = find_section(text, SECTION_NAMES["system"])
    if not sec:
        anchor = find_section(text, "Intent")
        ins_at = anchor[3] if anchor else 0
        block = f"\n# {SECTION_NAMES['system']}\n{SAFE_VERB_LINE}\n"
        return text[:ins_at] + block + text[ins_at:], True
    s = sec[2]; e = sec[3]
    body = text[s:e]
    if SAFE_VERB_LINE not in body:
        new_body = body.rstrip() + ("\n" if not body.endswith("\n") else "") + SAFE_VERB_LINE + "\n"
        return text[:s] + new_body + text[e:], True
    return text, False

def ensure_brand_notes(text):
    if find_section(text, SECTION_NAMES["brand"]):
        return text, False
    before = find_section(text, "Output Format")
    ins_at = before[2] if before else len(text)
    block = ("\n" if not text.endswith("\n") else "") + BRAND_BLOCK.strip() + "\n"
    return text[:ins_at] + block + text[ins_at:], True

def ensure_anonymisation(text):
    inp = find_section(text, SECTION_NAMES["input"])
    if inp:
        s,e = inp[2], inp[3]
        body = text[s:e]
        if ANON_LINE not in body:
            new = body.rstrip() + ("\n" if not body.endswith("\n") else "") + f"- {ANON_LINE}\n"
            return text[:s] + new + text[e:], True
        return text, False
    if not find_section(text, SECTION_NAMES["data"]):
        block = f"\n# {SECTION_NAMES['data']}\n- {ANON_LINE}\n"
        return text.rstrip() + block + ("\n" if not text.endswith("\n") else ""), True
    dh = find_section(text, SECTION_NAMES["data"])
    s,e = dh[2], dh[3]
    body = text[s:e]
    if ANON_LINE not in body:
        new = body.rstrip() + ("\n" if not body.endswith("\n") else "") + f"- {ANON_LINE}\n"
        return text[:s] + new + text[e:], True
    return text, False

def patch_prompt(pm_path, dry_run=False):
    with open(pm_path, "r", encoding="utf-8") as f:
        orig = f.read()
    changed_any = False
    t, ch = ensure_system_rules(orig); changed_any |= ch; orig = t
    t, ch = ensure_brand_notes(orig);  changed_any |= ch; orig = t
    t, ch = ensure_anonymisation(orig); changed_any |= ch; orig = t
    if changed_any and not dry_run:
        shutil.copy2(pm_path, pm_path + ".bak")
        with open(pm_path, "w", encoding="utf-8", newline="\n") as f:
            f.write(orig)
    return changed_any

def update_checksum(meta_path, pm_path, dry_run=False):
    if not os.path.isfile(meta_path): return False
    try:
        with open(meta_path, "r", encoding="utf-8") as f:
            meta = json.load(f)
    except Exception:
        return False
    new = sha256(pm_path)
    if meta.get("checksum_sha256") != new:
        if not dry_run:
            meta["checksum_sha256"] = new
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(meta, f, ensure_ascii=False, indent=2)
        return True
    return False

def process_dir(d, update_meta):
    pm = os.path.join(d, "prompt.md")
    mj = os.path.join(d, "meta.json")
    if not os.path.isfile(pm): return (False, False)
    changed = patch_prompt(pm, dry_run=args.dry_run)
    csum = False
    if update_meta and not args.dry_run:
        csum = update_checksum(mj, pm, dry_run=False)
    return (changed, csum)

def discover_dirs():
    found = []
    for base in CANDIDATE_DIRS:
        if not os.path.isdir(base): continue
        for pid in sorted(os.listdir(base)):
            d = os.path.join(base, pid)
            if os.path.isdir(d): found.append(d)
    return found

def parse_args():
    p = argparse.ArgumentParser(description="Auto-stamp safe-verbs, brand notes, and anonymisation note.")
    p.add_argument("--dry-run", action="store_true", help="Show what would change, do not write files.")
    p.add_argument("--no-checksum", action="store_true", help="Do not update meta.json checksum_sha256.")
    return p.parse_args()

if __name__ == "__main__":
    args = parse_args()
    dirs = discover_dirs()
    if not dirs:
        print("No prompt directories found.")
        sys.exit(0)

    touched = 0
    csum_upd = 0
    for d in dirs:
        ch, cs = process_dir(d, update_meta=(not args.no_checksum))
        if ch or cs:
            rel = os.path.relpath(d, PL)
            tags = []
            if ch: tags.append("STAMPED")
            if cs: tags.append("CHECKSUM")
            print(f"{' '.join(tags):<16} {rel}")
        touched += (1 if ch else 0)
        csum_upd += (1 if cs else 0)

    if args.dry_run:
        print("DRY_RUN complete.")
    else:
        print(f"Done. Updated {touched} prompt(s). Checksum syncs: {csum_upd}.")
