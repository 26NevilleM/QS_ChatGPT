import os, json, sys, zipfile
BASE = os.path.expanduser("~/Library/CloudStorage/GoogleDrive-design@qsurgical.co.za/My Drive/QS_ChatGPT/Vault")
if len(sys.argv)!=2:
    print("usage: pack_staff.py <version>")
    sys.exit(2)
version = sys.argv[1]
pl_root = os.path.join(BASE, "Prompt_Library")
cat_path = os.path.join(pl_root, "_catalog", "prompts_catalog.json")
with open(cat_path, "r", encoding="utf-8") as f:
    cat = json.load(f)
active_ids = cat.get("active", [])
files = []
for pid in active_ids:
    d = os.path.join(pl_root, "active", pid)
    pm = os.path.join(d, "prompt.md")
    mj = os.path.join(d, "meta.json")
    if os.path.isfile(pm):
        files.append((pm, f"Prompt_Library/active/{pid}/prompt.md"))
    if os.path.isfile(mj):
        files.append((mj, f"Prompt_Library/active/{pid}/meta.json"))
files.append((cat_path, "Prompt_Library/_catalog/prompts_catalog.json"))
out_dir = os.path.join(BASE, "Packs")
os.makedirs(out_dir, exist_ok=True)
out_zip = os.path.join(out_dir, f"Staff_CustomGPT_Pack_v{version}.zip")
with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for src, arc in files:
        if src.lower().endswith(".zip"):
            continue
        if not (src.lower().endswith(".md") or src.lower().endswith(".json")) and "prompts_catalog.json" not in arc:
            continue
        z.write(src, arcname=arc)
print(out_zip)
