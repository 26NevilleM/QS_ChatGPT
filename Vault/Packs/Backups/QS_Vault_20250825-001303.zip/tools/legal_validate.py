import os, sys, json, re

BASE = os.path.expanduser("~/Library/CloudStorage/GoogleDrive-design@qsurgical.co.za/My Drive/QS_ChatGPT/Vault")
PL = os.path.join(BASE, "Prompt_Library")
BANNED = [
  "cures",
  "cure",
  "proves",
  "prove",
  "guarantees",
  "guarantee",
  "prevents",
  "eliminates",
  "eliminate",
  "100%",
  "zero risk",
  "diagnose",
  "diagnoses",
  "treats",
  "treat",
  "heals",
  "heal",
  "miracle",
  "safe for all",
  "no side effects"
]

def scan_file(path):
    txt = open(path, "r", encoding="utf-8", errors="ignore").read()
    hits = []
    for term in BANNED:
        pattern = re.compile(r"\b" + re.escape(term) + r"\b", re.IGNORECASE)
        if pattern.search(txt):
            hits.append(term)
    return hits

def main():
    active_dir = os.path.join(PL, "active")
    if not os.path.isdir(active_dir):
        print("no_active_dir")
        sys.exit(2)
    violations = []
    for root, dirs, files in os.walk(active_dir):
        for name in files:
            if not (name.endswith(".md") or name.endswith(".json")):
                continue
            path = os.path.join(root, name)
            hits = scan_file(path)
            if hits:
                rel = os.path.relpath(path, BASE)
                violations.append((rel, sorted(set(hits))))
    if violations:
        for rel, ht in violations:
            print(f"VIOLATION: {rel} -> {{'banned_terms': {ht}}}")
        sys.exit(1)
    print("LEGAL_OK")

if __name__ == "__main__":
    main()
