# Name
Test Prompt v1

# Intent
Verify that the Prompt Library is functional.

# Input Format
Simple test question.- Include anonymised inputs; remove personal identifiers and non-essential data.
# System Rules
Use safe verbs only. Comply with brand DNA.- Safe verbs only; comply with brand DNA.- Use safe verbs only.
# Output Format
Short, precise response.

## Brand Notes
- Use safe verbs (support, help, enable, suggest).
- Avoid aim to, absolutes, superlatives, and unverifiable claims.
- Keep tone clear, compassionate, and professional.
---
*Compliance Notes:* Use safe verbs. Avoid absolutes or aim to. Do not imply therapeutic certainty. POPIA: exclude identifiers; use approved channels for any case details.
## Safe Verbs
Use: aim to, help, may, support, suggest, indicate, reduce, lower, typically.
Avoid: aim to, support, reduce, reduce, typically, generally not, 100%, lower risk/complications.
*Anonymisation:* remove names, IDs, contact details, and dates unless strictly required.
