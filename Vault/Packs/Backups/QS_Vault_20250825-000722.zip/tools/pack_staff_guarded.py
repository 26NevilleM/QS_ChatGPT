import os, sys, subprocess

BASE=os.path.expanduser("~/Library/CloudStorage/GoogleDrive-design@qsurgical.co.za/My Drive/QS_ChatGPT/Vault")
TOOLS=os.path.join(BASE,"tools")
VALIDATE_ALL=os.path.join(TOOLS,"validate_all.py")
PACK_STAFF=os.path.join(TOOLS,"pack_staff.py")

if len(sys.argv)!=2:
    print("usage: pack_staff_guarded.py <version>")
    sys.exit(2)

vres=subprocess.run(["python3", VALIDATE_ALL], capture_output=True, text=True)
print(vres.stdout, end="")
if vres.stderr: print(vres.stderr, file=sys.stderr, end="")
if vres.returncode!=0:
    print("PACK_ABORTED: validation failed.")
    sys.exit(vres.returncode)

pres=subprocess.run(["python3", PACK_STAFF, sys.argv[1]], capture_output=True, text=True)
print(pres.stdout, end="")
if pres.stderr: print(pres.stderr, file=sys.stderr, end="")
sys.exit(pres.returncode)
