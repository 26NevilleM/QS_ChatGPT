#!/usr/bin/env python3
import argparse, subprocess, sys, os, shlex

BASE=os.path.expanduser(os.environ.get("QS",""))
TOOLS=os.path.join(BASE,"tools")
VALIDATE_ALL=os.path.join(TOOLS,"validate_all.py")
RELEASE=os.path.join(TOOLS,"release.py")
WRAP_GUARD=os.path.join(TOOLS,"wrap_guard.py")

def run(cmd, check=False):
    print("▶", "Running:", " ".join(shlex.quote(c) for c in cmd))
    p=subprocess.run(cmd, text=True)
    if check and p.returncode!=0: sys.exit(p.returncode)
    return p

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--roles", default="finance,hr")
    ap.add_argument("--level", choices=["major","minor","patch"], default="minor")
    ap.add_argument("--notes", default="Automated batch release.")
    args=ap.parse_args()

    roles=[r.strip() for r in args.roles.split(",") if r.strip()]
    if not roles:
        print("No roles found. Nothing to do."); return 0

    print("== VALIDATE ONCE ==")
    run(["python3", VALIDATE_ALL], check=True)

    print("== RELEASE PER ROLE ==")
    for role in roles:
        level = "minor" if args.level=="patch" else args.level
        print(f"\n-- releasing: {role} ({args.level}) --")
        cmd = ["python3", WRAP_GUARD, RELEASE, role, level, args.notes]
        rc = run(cmd).returncode
        if rc!=0:
            print(f"ABORT: release failed for role '{role}'."); sys.exit(rc)

    print("\nBATCH_RELEASE_OK"); return 0

if __name__=="__main__": sys.exit(main())
