import json, os, sys, shutil, datetime
BASE = os.path.expanduser("~/Library/CloudStorage/GoogleDrive-design@qsurgical.co.za/My Drive/QS_ChatGPT/Vault")
if len(sys.argv)!=2:
    print("usage: promote_prompt.py <prompt_id>")
    sys.exit(2)
pid = sys.argv[1]
root = os.path.join(BASE, "Prompt_Library")
cat_path = os.path.join(root, "_catalog", "prompts_catalog.json")
src = os.path.join(root, "sandbox", pid)
dst = os.path.join(root, "active", pid)
if not os.path.isdir(src):
    print("not_found_in_sandbox")
    sys.exit(3)
with open(cat_path, "r", encoding="utf-8") as f:
    cat = json.load(f)
if pid not in cat.get("sandbox", []):
    cat.setdefault("sandbox", []).append(pid)
os.makedirs(os.path.dirname(dst), exist_ok=True)
if os.path.isdir(dst):
    print("already_active")
    sys.exit(4)
shutil.move(src, dst)
if pid in cat.get("sandbox", []):
    cat["sandbox"] = [x for x in cat["sandbox"] if x!=pid]
cat.setdefault("active", [])
if pid not in cat["active"]:
    cat["active"].append(pid)
meta_path = os.path.join(dst, "meta.json")
with open(meta_path, "r", encoding="utf-8") as f:
    meta = json.load(f)
meta["status"] = "active"
meta["updated"] = datetime.date.today().isoformat()
with open(meta_path, "w", encoding="utf-8") as f:
    json.dump(meta, f, ensure_ascii=False, indent=2)
with open(cat_path, "w", encoding="utf-8") as f:
    json.dump(cat, f, ensure_ascii=False, indent=2)
print("OK")
