#!/usr/bin/env python3
import os, sys, subprocess

BASE=os.path.expanduser("~/Library/CloudStorage/GoogleDrive-design@qsurgical.co.za/My Drive/QS_ChatGPT/Vault")
TOOLS=os.path.join(BASE,"tools")

VALIDATORS=[
    os.path.join(TOOLS,"validate_prompts.py"),
    os.path.join(TOOLS,"brand_validate.py"),
    os.path.join(TOOLS,"legal_validate.py"),
]

def run(cmd):
    p=subprocess.run(["python3",cmd], capture_output=True, text=True)
    sys.stdout.write(p.stdout)
    sys.stderr.write(p.stderr)
    return p.returncode

def main():
    for v in VALIDATORS:
        if not os.path.isfile(v):
            print(f"ERROR: missing validator -> {v}")
            sys.exit(2)
        code=run(v)
        if code!=0:
            label = "BRAND_FAIL" if v.endswith("brand_validate.py") else ("COMPLIANCE_FAIL" if v.endswith("legal_validate.py") else "VALIDATION_FAIL")
            print(label)
            sys.exit(code)
    print("ALL_VALIDATIONS_OK")
if __name__=="__main__":
    main()
