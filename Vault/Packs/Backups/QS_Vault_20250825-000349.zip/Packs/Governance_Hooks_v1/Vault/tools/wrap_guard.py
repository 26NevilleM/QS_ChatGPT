#!/usr/bin/env python3
import os, sys, subprocess

BASE=os.path.expanduser("~/Library/CloudStorage/GoogleDrive-design@qsurgical.co.za/My Drive/QS_ChatGPT/Vault")
TOOLS=os.path.join(BASE,"tools")
VALIDATE_ALL=os.path.join(TOOLS,"validate_all.py")

def main():
    if len(sys.argv) < 2:
        print("usage: wrap_guard.py <python_script_in_tools> [args...]")
        sys.exit(2)
    target = os.path.join(TOOLS, sys.argv[1])
    args = sys.argv[2:]

    vres=subprocess.run(["python3", VALIDATE_ALL], capture_output=True, text=True)
    print(vres.stdout, end="")
    if vres.stderr: print(vres.stderr, file=sys.stderr, end="")
    if vres.returncode!=0:
        print("ABORTED: validation failed.")
        sys.exit(vres.returncode)

    if not os.path.isfile(target):
        print(f"ERROR: target script not found -> {target}")
        sys.exit(2)

    pres=subprocess.run(["python3", target] + args, capture_output=True, text=True)
    print(pres.stdout, end="")
    if pres.stderr: print(pres.stderr, file=sys.stderr, end="")
    sys.exit(pres.returncode)

if __name__=="__main__":
    main()
