import os, sys, json, datetime, subprocess

BASE=os.path.expanduser("~/Library/CloudStorage/GoogleDrive-design@qsurgical.co.za/My Drive/QS_ChatGPT/Vault")
VERS=os.path.join(BASE,"Master","versions.json")
CHG_DIR=os.path.join(BASE,"Changelog")
TOOLS=os.path.join(BASE,"tools")
VALIDATE_ALL=os.path.join(TOOLS,"validate_all.py")
PACK_ROLE=os.path.join(TOOLS,"pack_role.py")

if len(sys.argv)<3:
    print("usage: release.py <role> <bump:major|minor> [notes...]")
    sys.exit(2)

role=sys.argv[1].lower()
bump=sys.argv[2].lower()
notes=" ".join(sys.argv[3:]).strip()

# 1) Run all validations (schema + legal). Fail closed.
if not os.path.isfile(VALIDATE_ALL):
    print("ERROR: validate_all.py missing. Add it under Vault/tools.")
    sys.exit(2)
vres=subprocess.run(["python3", VALIDATE_ALL], capture_output=True, text=True)
print(vres.stdout, end="")
if vres.stderr: print(vres.stderr, file=sys.stderr, end="")
if vres.returncode!=0:
    print("RELEASE_ABORTED: validation failed.")
    sys.exit(vres.returncode)

# 2) Load and bump version
with open(VERS,"r",encoding="utf-8") as f:
    versions=json.load(f)
cur=versions.get(role,"0.0")
try:
    major,minor=map(int,cur.split("."))
except:
    major,minor=0,0
if bump=="major":
    major+=1; minor=0
elif bump=="minor":
    minor+=1
else:
    print("bump must be major or minor")
    sys.exit(3)
new=f"{major}.{minor}"
versions[role]=new
with open(VERS,"w",encoding="utf-8") as f:
    json.dump(versions,f,ensure_ascii=False,indent=2)

# 3) Pack role zip
if not os.path.isfile(PACK_ROLE):
    print("ERROR: pack_role.py missing.")
    sys.exit(2)
pres=subprocess.run(["python3", PACK_ROLE, role, new], capture_output=True, text=True)
print(pres.stdout, end="")
if pres.stderr: print(pres.stderr, file=sys.stderr, end="")
if pres.returncode!=0:
    print("RELEASE_ABORTED: packaging failed.")
    sys.exit(pres.returncode)
zip_path=pres.stdout.strip().splitlines()[-1]

# 4) Changelog entry
today=datetime.date.today().isoformat()
chg_path=os.path.join(CHG_DIR,f"Notes_{today}.md")
entry=f"## {role.capitalize()} Role Pack v{new}\n- {notes if notes else 'Updated release.'}\n- Built from active prompts for role.\n- Validation: PASS (schema + legal).\n\n"
if os.path.exists(chg_path):
    with open(chg_path,"a",encoding="utf-8") as f: f.write(entry)
else:
    header=f"# Q-Surgical Prompt Library Changelog\nDate: {today}\nAuthor: Neville Meth\n\n"
    with open(chg_path,"w",encoding="utf-8") as f:
        f.write(header+entry)

print(zip_path)
