#!/usr/bin/env python3
import os, re, datetime

QS = os.environ.get("QS") or os.path.expanduser("~/Library/CloudStorage/GoogleDrive-design@qsurgical.co.za/My Drive/QS_ChatGPT/Vault")
CHG_DIR = os.path.join(QS, "Changelog")
INDEX = os.path.join(CHG_DIR, "_INDEX.md")

HDR = "# Q‑Surgical Prompt Library – Changelog Index\n\n"
ROW_HDR = "| Date | File | Entries |\n|---|---|---|\n"

def collect():
    items=[]
    if not os.path.isdir(CHG_DIR): return items
    for fn in os.listdir(CHG_DIR):
        if not fn.startswith("Notes_") or not fn.endswith(".md"): continue
        path=os.path.join(CHG_DIR, fn)
        try:
            with open(path,"r",encoding="utf-8") as f: txt=f.read()
        except Exception:
            continue
        # collect headings like "## Finance Role Pack v1.2"
        heads=re.findall(r"(?m)^##\s+(.+)$", txt)
        # date from filename: Notes_YYYY-MM-DD.md
        m=re.match(r"Notes_(\d{4}-\d{2}-\d{2})\.md$", fn)
        date=m.group(1) if m else ""
        items.append((date, fn, "; ".join(h.strip() for h in heads) or "—"))
    # newest first
    items.sort(key=lambda x: x[0], reverse=True)
    return items

def write_index(items):
    os.makedirs(CHG_DIR, exist_ok=True)
    with open(INDEX,"w",encoding="utf-8",newline="\n") as f:
        f.write(HDR)
        f.write(ROW_HDR)
        for date, fn, heads in items:
            f.write(f"| {date} | {fn} | {heads} |\n")
    print(INDEX)

def main():
    items=collect()
    write_index(items)
    print("CHANGELOG_INDEX_UPDATED")
    return 0

if __name__=="__main__":
    raise SystemExit(main())
