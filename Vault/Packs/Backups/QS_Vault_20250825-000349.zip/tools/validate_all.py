#!/usr/bin/env python3
import os, sys, re, json, hashlib

# === Paths ===
BASE = os.path.expanduser("~/Library/CloudStorage/GoogleDrive-design@qsurgical.co.za/My Drive/QS_ChatGPT/Vault")
PL   = os.path.join(BASE, "Prompt_Library")
CATALOG = os.path.join(PL, "_catalog", "prompts_catalog.json")

# === Shared helpers ===
SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")
REQUIRED_HEADERS = [r"^# Name\s*$", r"^# Intent\s*$", r"^# Input Format\s*$", r"^# System Rules\s*$", r"^# Output Format\s*$"]
MAX_LINE_CHARS = 180

# Content prohibitions (blocking)
PROHIBITED_VERBS = re.compile(r"\b(cure|cures|guarantee|guarantees|guaranteed|zero complications|100%|eliminate[s]?|banish|miracle)\b", re.I)

# Brand checks
BANNED_STYLE = re.compile(r"\b(cartoon(y)?|comic\s*Sans|clipart|goofy|meme\-y)\b", re.I)
BRAND_TOKENS = [
    "#000000", "#B5D443", "#FFFFFF",
    "Good Times", "Bahnschrift",
    "sleek", "futuristic", "high-contrast", "holographic", "wireframe", "sci-fi"
]

# Legal checks
HARD_CLAIMS = re.compile(r"\b(cure|cures|guarantee(d|s)?|100%|zero complications|no complications|prevent[s]? all)\b", re.I)
PII_REQUESTS = re.compile(r"\b(patient\s*name|ID\s*number|passport|phone\s*number|email\s*address)\b", re.I)
UNAPPROVED_PROMO = re.compile(r"\b(clinical\s*proof|clinically\s*proven|efficacy\s*guarantee)\b", re.I)
SUGGEST_ANON = re.compile(r"\b(anonymi[sz]e|de\-identify|no\s+identifiers|no\s+PII)\b", re.I)
SAFE_VERB_HINTS = re.compile(r"\b(supports|helps|enables)\b", re.I)

def green(text):  return f"\033[92m{text}\033[0m"
def red(text):    return f"\033[91m{text}\033[0m"

def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def load_catalog():
    if not os.path.isfile(CATALOG):
        print(f"ERROR: missing catalog -> {CATALOG}")
        sys.exit(2)
    try:
        with open(CATALOG, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"ERROR: invalid catalog JSON -> {CATALOG}: {e}")
        sys.exit(2)

def collect_ids(cat):
    ids = []
    for k in ("active", "sandbox"):
        ids.extend(cat.get(k, []))
    return ids

def prompt_paths(pid: str):
    d = os.path.join(PL, "active", pid)
    if not os.path.isdir(d):
        d = os.path.join(PL, "sandbox", pid)
    return os.path.join(d, "prompt.md"), os.path.join(d, "meta.json")

# === Schema / Content validator ===
def validate_schema_and_content(pid):
    issues, warns = [], []
    pp, mp = prompt_paths(pid)

    if not os.path.isfile(pp):
        issues.append(f"missing_prompt_md:{pid}")
        return issues, warns
    if not os.path.isfile(mp):
        issues.append(f"missing_meta_json:{pid}")
        return issues, warns

    # meta.json
    try:
        meta = json.load(open(mp, "r", encoding="utf-8"))
    except Exception as e:
        issues.append(f"meta_json_invalid:{pid}:{e}")
        return issues, warns

    for k in ["id", "title", "version", "status"]:
        if not meta.get(k): issues.append(f"meta_missing_{k}:{pid}")

    if meta.get("id") and meta["id"] != pid:
        issues.append(f"meta_id_mismatch:{pid}")

    v = meta.get("version", "")
    if not SEMVER_RE.match(v):
        issues.append(f"meta_version_semver:{pid}")

    if meta.get("status") not in ("active", "sandbox", "deprecated"):
        issues.append(f"meta_status_invalid:{pid}")

    for opt in ["owner", "persona", "use_case", "tags"]:
        if not meta.get(opt):
            warns.append(f"WARN meta_optional_missing_{opt}:{pid}")

    exp = meta.get("checksum_sha256", "")
    if exp:
        actual = sha256(pp)
        if actual != exp:
            issues.append(f"checksum_mismatch:{pid}")
    else:
        warns.append(f"WARN meta_checksum_empty:{pid}")

    # prompt.md
    text = open(pp, "r", encoding="utf-8").read()

    for hdr in REQUIRED_HEADERS:
        if not re.search(hdr, text, flags=re.MULTILINE):
            issues.append(f"prompt_missing_header:{pid}:{hdr}")

    if PROHIBITED_VERBS.search(text):
        issues.append(f"prompt_prohibited_verbs:{pid}")

    for i, line in enumerate(text.splitlines(), start=1):
        if len(line) > MAX_LINE_CHARS:
            warns.append(f"WARN long_line:{pid}:{i}:{len(line)}")

    if "safe verbs" not in text.lower():
        warns.append(f"WARN system_rules_missing_safe_verbs_note:{pid}")

    return issues, warns

# === Brand validator ===
def validate_brand(pid):
    pp, _ = prompt_paths(pid)
    if not os.path.isfile(pp):  # schema handles
        return [], []
    text = open(pp, "r", encoding="utf-8").read()

    issues, warns = [], []

    if BANNED_STYLE.search(text):
        issues.append(f"brand_banned_style:{pid}")

    if not any(tok.lower() in text.lower() for tok in BRAND_TOKENS):
        warns.append(f"WARN brand_notes_absent:{pid}")

    if text.count("!") >= 5:
        warns.append(f"WARN excessive_exclamation:{pid}:{text.count('!')}")

    return issues, warns

# === Legal validator ===
def validate_legal(pid):
    pp, _ = prompt_paths(pid)
    if not os.path.isfile(pp):
        return [], []
    text = open(pp, "r", encoding="utf-8").read()

    issues, warns = [], []

    if HARD_CLAIMS.search(text):
        issues.append(f"legal_hard_claim:{pid}")
    if PII_REQUESTS.search(text):
        issues.append(f"legal_pii_request:{pid}")
    if UNAPPROVED_PROMO.search(text):
        issues.append(f"legal_unapproved_promo:{pid}")

    if ("case" in text.lower() or "success" in text.lower()) and not SUGGEST_ANON.search(text):
        warns.append(f"WARN suggest_anonymisation_note:{pid}")

    if not SAFE_VERB_HINTS.search(text):
        warns.append(f"WARN safe_verbs_missing:{pid}")

    return issues, warns

def main():
    cat = load_catalog()
    ids = collect_ids(cat)

    all_warns, all_issues = [], []

    for pid in ids:
        i1, w1 = validate_schema_and_content(pid)
        i2, w2 = validate_brand(pid)
        i3, w3 = validate_legal(pid)
        all_warns.extend(w1 + w2 + w3)
        all_issues.extend(i1 + i2 + i3)

    # Print WARNs first (non‑blocking)
    for w in all_warns:
        print(w)

    if all_issues:
        print("\n".join(all_issues))
        print(red("VALIDATIONS_FAILED"))
        sys.exit(1)

    print(green("ALL_VALIDATIONS_OK"))

if __name__ == "__main__":
    main()