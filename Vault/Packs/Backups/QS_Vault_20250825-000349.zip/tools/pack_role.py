import os, json, sys, zipfile
BASE=os.path.expanduser("~/Library/CloudStorage/GoogleDrive-design@qsurgical.co.za/My Drive/QS_ChatGPT/Vault")
if len(sys.argv)!=3:
    print("usage: pack_role.py <role> <version>")
    sys.exit(2)
role=sys.argv[1].lower()
version=sys.argv[2]
label_map={"staff":"Staff","finance":"Finance","hr":"HR"}
label=label_map.get(role, role.capitalize())
pl_root=os.path.join(BASE,"Prompt_Library")
cat_path=os.path.join(pl_root,"_catalog","prompts_catalog.json")
with open(cat_path,"r",encoding="utf-8") as f:
    cat=json.load(f)
active_ids=[pid for pid in cat.get("active",[]) if pid.lower().startswith(role+"_")]
files=[]
for pid in active_ids:
    d=os.path.join(pl_root,"active",pid)
    pm=os.path.join(d,"prompt.md"); mj=os.path.join(d,"meta.json")
    if os.path.isfile(pm): files.append((pm,f"Prompt_Library/active/{pid}/prompt.md"))
    if os.path.isfile(mj): files.append((mj,f"Prompt_Library/active/{pid}/meta.json"))
catalog={"active":active_ids,"sandbox":[],"deprecated":[]}
out_dir=os.path.join(BASE,"Packs"); os.makedirs(out_dir,exist_ok=True)
out_zip=os.path.join(out_dir,f"{label}_RolePack_v{version}.zip")
with zipfile.ZipFile(out_zip,"w",compression=zipfile.ZIP_DEFLATED) as z:
    z.writestr("Prompt_Library/_catalog/prompts_catalog.json",json.dumps(catalog,indent=2))
    for src,arc in files:
        if src.lower().endswith(".zip"): continue
        if not (src.lower().endswith(".md") or src.lower().endswith(".json")): continue
        z.write(src,arcname=arc)
print(out_zip)
