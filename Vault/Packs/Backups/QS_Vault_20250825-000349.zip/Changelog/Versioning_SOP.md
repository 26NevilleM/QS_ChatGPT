# Versioning & Governance SOP

## Objective
Maintain clear, auditable records of all Prompt Library and Role Pack changes.

## Versioning Rules
- Format: `<Role>_RolePack_vX.Y`
- Major (X): bump when structure changes (new prompts, persona shift, compliance overhaul).
- Minor (Y): bump when prompt text, formatting, or metadata is updated.
- Hotfix: suffix `-hotfix` if an urgent fix is applied outside the normal cycle.

## Workflow
1. Increment version number (X.Y) for each release or update.
2. Generate updated pack zip and place in `/Vault/Packs/`.
3. Add an entry to `/Vault/Changelog/Notes_YYYY-MM-DD.md`:
   - Role Pack name + version.
   - Summary of changes.
   - Validation status (PASS/FAIL).
4. If hotfix applied:
   - Add `-hotfix` to version.
   - Document reason clearly in changelog.
5. Sync updated zips to Google Drive under `/QS_ChatGPT/Vault/Packs/`.
6. Validate by running smoke tests in CustomGPT for the updated pack.
7. Archive superseded versions in `/Vault/Archive/` if no longer active.

## Compliance Notes
- Always use safe verbs (supports, enables, helps).
- Align with Q-Surgical Brand DNA and compliance guardrails (POPIA/SAHPRA).
- Never delete changelog entries; append new files instead.

## Roles & Responsibility
- **Owner:** Neville Meth
- **Custodian:** Q-Surgical Brand & AI Governance
- **Contributors:** Any persona (Picasso, Navigator, Operator, LegalEagle) when producing updates.

