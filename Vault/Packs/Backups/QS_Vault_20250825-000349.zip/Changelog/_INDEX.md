# Q‑Surgical Prompt Library – Changelog Index

| Date | File | Entries |
|---|---|---|
| 2025-08-25 | Notes_2025-08-25.md | Finance Role Pack v1.7; Hr Role Pack v2.7 |
| 2025-08-24 | Notes_2025-08-24.md | Staff Role Pack v1.2; Finance Role Pack v1.0; HR Role Pack v1.1; Finance Role Pack v1.1; Hr Role Pack v2.0; Hr Role Pack v2.1; Hr Role Pack v2.2; Finance Role Pack v1.2; Hr Role Pack v2.3; Finance Role Pack v1.3; Hr Role Pack v2.4; Finance Role Pack v1.4; Hr Role Pack v2.5; Finance Role Pack v1.5; Finance Role Pack v1.6; Hr Role Pack v2.6 |
