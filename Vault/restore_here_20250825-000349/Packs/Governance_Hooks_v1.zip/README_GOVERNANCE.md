# Governance Hooks v1

Adds brand validation and routes all packaging through brand + legal checks.

## Install
1) Copy `Vault/Master/Brand_DNA.md` into your Vault.
2) Copy `Vault/tools/brand_validate.py`, `Vault/tools/validate_all.py` (overwrite), and `Vault/tools/wrap_guard.py` into `Vault/tools/`.
3) Run `qsval`.

## Expected output
```
BRAND_OK
LEGAL_OK
ALL_VALIDATIONS_OK
```

## Guard any tool
```
python3 "$QS/tools/wrap_guard.py" pack_staff.py 1.7
```
